using System;
using System.IO;

namespace МПП
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = File.ReadAllText(@"text1.txt");
            string[] words = new string [1000];
            int[] counts = new int[1000];

            string cur_word = "";
            int i = 0;
            int k = 0;
            int N = 0;
            int N_max = 6 - 1;
            
            first_circle_of_hell:
                if(text[i] == '.' || text[i] == ',' || text[i] == '?' || text[i] == '!' || text[i] == '-' || text[i] == ' '){
                    if(cur_word!="for" && cur_word!="the" && cur_word!="in" && cur_word!="is" && cur_word!="a" && cur_word!="from"){
                        i++;
                        goto second_circle_of_hell;
                    }
                    cur_word = "";
                }
                else{
                    char cur_char;
                    cur_char = text[i];
                    if((cur_char >= 65) && (cur_char <= 90) || (cur_char >= 97) && (cur_char <= 122) || cur_char == 45)
                        {
                        if ((text[i] >= 65) && (text[i] <= 90))
                        {
                            cur_word += (char)(cur_char + 32);
                        }
                        else
                        {
                            cur_word += cur_char;
                        }
                    }
                }
                i++;
                if(text.Length != i){
                    goto first_circle_of_hell;
                }
                else{
                    goto sort_of_end;
                }

            second_circle_of_hell:
                if(words[k]==null){
                    words[k] = cur_word;
                    counts[k] = 1;
                    cur_word = "";
                    N++;
                    k=0;
                    goto first_circle_of_hell;
                }
                else{
                    if(cur_word == words[k]){
                        counts[k]++;
                        cur_word="";
                        k=0;
                        goto first_circle_of_hell;
                    }
                    k++;
                }
                goto second_circle_of_hell;
            sort_of_end:
            int i_m = -1;
            int i_b = 0;
                hell_1:
                    i_m++;
                    if(i_m == N)
                        goto end;
                    else{
                        goto hell_2;
                    }
                    hell_2:
                        if(counts[i_b] < counts[i_b+1]){
                            var t = counts[i_b];
                            counts[i_b] = counts[i_b+1];
                            counts[i_b+1] = t;
                            var t_str = words[i_b];
                            words[i_b] = words[i_b+1];
                            words[i_b+1] = t_str;
                        }
                        if(i_b != N){
                            i_b++;
                            goto hell_2;
                        }
                        else{
                            i_b=0;
                            goto hell_1;
                        };
            end:
                Console.WriteLine(words[k] + " - " + counts[k]);
                k++;
                if(words[k] != null && N_max != 0){
                N_max--;
                    goto end;}
        }
    }
}
