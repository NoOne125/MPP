using System;
using System.IO;

namespace МПП
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = File.ReadAllText(@"text2.txt");
            string[] words = new string [10000];
            int[] counts = new int[10000];
            int [,] pages = new int[10000, 100];

            string cur_word = "";
            int i = 0;
            int k = 0;
            int N = 0;
            int stringggggg = 1;
            
            first_circle_of_hell:
            if(text.Length == i)
                goto end;
                if((text[i] == '.' || text[i] == ',' || text[i] == '?' || text[i] == '!' || text[i] == '-' || text[i] == '“' || text[i] == '”' || text[i] == ';' || text[i] == ' ') && cur_word!=""){
                    i++;
                    goto second_circle_of_hell;
                }
                else{
                    char cur_char;
                    cur_char = text[i];
                    if((cur_char >= 65) && (cur_char <= 90) || (cur_char >= 97) && (cur_char <= 122) || cur_char == 45)
                        {
                        if ((text[i] >= 65) && (text[i] <= 90))
                        {
                            cur_word += (char)(cur_char + 32);
                        }
                        else
                        {
                            cur_word += cur_char;
                        }
                    }
                    else if(cur_char=='\r')
                    stringggggg++;
                }
                i++;
                if(text.Length != i){
                    goto first_circle_of_hell;
                }
                else{
                    goto end;
                }

            second_circle_of_hell:
                if(words[k]==null){
                    words[k] = cur_word;
                    counts[k] = 1;
                    pages[k,0] = stringggggg/5 +1;
                    cur_word = "";
                    N++;
                    k=0;
                    goto first_circle_of_hell;
                }
                else{
                    if(cur_word == words[k]){
                        counts[k]++;
                        int z = 1;
                        third_circle_of_hell:
                            if(pages[k,z] == 0)
                                pages[k,z] = stringggggg/5+1;
                            else if(z==99)
                                {

                                }
                            else{
                                z++;
                                goto third_circle_of_hell;
                            }
                            z = 0;
                        cur_word="";
                        k=0;
                        goto first_circle_of_hell;
                    }
                    k++;
                }
                goto second_circle_of_hell;
            end:
                int c = 1;
                string x = " "+pages[k,0];
                end_2:
                    if(c==100){
                        k++;
                        c=0;
                        goto end;
                    }
                    if(pages[k,c]!=0){
                        x+=", " + pages[k,c];
                        c++;
                        goto end_2;
                    }
                    else{
                        
                    }
                Console.WriteLine(words[k] + " - " + x);
                k++;
                if(words[k] != null)
                    goto end;
        }
    }
}
